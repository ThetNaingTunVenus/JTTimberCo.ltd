from django.apps import AppConfig


class TimberappConfig(AppConfig):
    name = 'timberapp'
